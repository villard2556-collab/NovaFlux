package com.example.iptvreader.utils
import okhttp3.*
import okhttp3.logging.HttpLoggingInterceptor
import java.io.File
import java.io.IOException
object Network {
  private lateinit var client: OkHttpClient
  fun init(cacheDir: File) {
    val cache = Cache(File(cacheDir, "http_cache"), 20L * 1024L * 1024L)
    val logger = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
    client = OkHttpClient.Builder()
      .connectTimeout(java.time.Duration.ofSeconds(10))
      .readTimeout(java.time.Duration.ofSeconds(20))
      .writeTimeout(java.time.Duration.ofSeconds(20))
      .cache(cache)
      .addInterceptor { chain ->
        val req = chain.request().newBuilder().header("User-Agent","NovaFluxIPTV/1.0").build()
        chain.proceed(req)
      }
      .addInterceptor(logger)
      .build()
  }
  fun fetchText(url:String):String?{
    if(!::client.isInitialized) throw IllegalStateException("Network not initialized")
    val r = Request.Builder().url(url).build()
    client.newCall(r).execute().use { res -> if(!res.isSuccessful) throw IOException("HTTP ${res.code}"); return res.body?.string() }
  }
}
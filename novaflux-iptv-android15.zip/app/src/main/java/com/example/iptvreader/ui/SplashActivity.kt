package com.example.iptvreader.ui
import android.content.Intent; import android.os.*; import androidx.appcompat.app.AppCompatActivity
import com.example.iptvreader.data.Prefs; import com.example.iptvreader.databinding.ActivitySplashBinding; import com.example.iptvreader.utils.Network
class SplashActivity:AppCompatActivity(){ private lateinit var b:ActivitySplashBinding
  override fun onCreate(s:Bundle?){ super.onCreate(s); b=ActivitySplashBinding.inflate(layoutInflater); setContentView(b.root); Network.init(cacheDir)
    Handler(Looper.getMainLooper()).postDelayed({ val prefs=Prefs(this); if(prefs.isLoggedIn()) startActivity(Intent(this,DashboardActivity::class.java)) else startActivity(Intent(this,AuthActivity::class.java)); finish() },900) }
}
package com.example.iptvreader.model
data class Channel(val name:String,val url:String,val category:String?,val logo:String?)

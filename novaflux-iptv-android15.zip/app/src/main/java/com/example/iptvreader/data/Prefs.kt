package com.example.iptvreader.data
import android.content.Context
class Prefs(ctx: Context) {
  private val sp = ctx.getSharedPreferences("iptv_prefs", Context.MODE_PRIVATE)
  var serverUrl:String? get()=sp.getString("serverUrl",null) set(v){ sp.edit().putString("serverUrl",v).apply() }
  var username:String? get()=sp.getString("username",null) set(v){ sp.edit().putString("username",v).apply() }
  var password:String? get()=sp.getString("password",null) set(v){ sp.edit().putString("password",v).apply() }
  fun isLoggedIn() = !serverUrl.isNullOrBlank() && !username.isNullOrBlank() && !password.isNullOrBlank()
  fun logout() = sp.edit().clear().apply()
}
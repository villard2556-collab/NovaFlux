package com.example.iptvreader.utils
import com.example.iptvreader.model.Channel
object M3UParser{
  fun parseM3U(content:String):List<Channel>{
    val out=mutableListOf<Channel>(); val lines=content.lines()
    var i=0; while(i<lines.size){
      val line=lines[i].trim()
      if(line.startsWith("#EXTINF:",true)){
        val name=line.substringAfterLast(",").trim().ifEmpty{"Sans nom"}
        var j=i+1; while(j<lines.size&&lines[j].isBlank()) j++
        if(j<lines.size){ val url=lines[j].trim(); if(url.startsWith("http",true)||url.startsWith("rtmp",true)) out.add(Channel(name,url,null,null)); i=j }
      }; i++
    }; return out
  }
}